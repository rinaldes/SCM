/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package epson;

import java.applet.Applet;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.jnlp.*;
import javax.print.Doc;
import javax.print.DocFlavor;
import javax.print.DocPrintJob;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.SimpleDoc;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import simple.escp.SimpleEscp;
import simple.escp.data.DataSources;
import simple.escp.fill.FillJob;
import simple.escp.json.JsonTemplate;
import sun.print.UnixPrintJob;

/**
 *
 * @author dean
 */
public class Epson extends Applet {

    public String title;
    public String npwp;
    public String address1;
    public String address2;
    public String po;
    public String total;
    public String ppn;
    public String grandtotal;

    public String sname;
    public String saddress;
    public String scity;
    public String sphone;
    public String sfax;
    public String semail;
    public String sperson;

    public String tname;
    public String taddress;
    public String tcity;
    public String tphone;
    public String tfax;
    public String tnpwp;

    public String tglterima;
    public String noterima;
    public String nofaktur;
    public String remark;
    public String tglpo;
    public String nopo;
    public String kode;
    public String kodesup;
    public String namasup;
    public String tgl;

//    public static void main(String[] args) {
//    }
//    @Override
//    public void init() {
//        print_gr(null);
//    }
    
    public String hello() {
        return "V1.0.5";
    }
    
    public Map<String, Object> getMapPo() {
        Map<String, Object> map = new HashMap<>();
        map.put("title", title);
        map.put("npwp", npwp);
        map.put("address1", address1);
        map.put("address2", address2);
        map.put("po", po);
        map.put("total", total);
        map.put("ppn", ppn);
        map.put("grandtotal", grandtotal);

        map.put("sname", sname);
        map.put("saddress", saddress);
        map.put("scity", scity);
        map.put("sphone", sphone);
        map.put("sfax", sfax);
        map.put("semail", semail);
        map.put("sperson", sperson);

        map.put("tname", tname);
        map.put("taddress", taddress);
        map.put("tcity", tcity);

        map.put("tphone", tphone);
        map.put("tfax", tfax);
        map.put("tnpwp", tnpwp);

        return map;
    }

    public Map<String, Object> getMapGr() {
        Map<String, Object> map = new HashMap<>();

        map.put("tglterima", tglterima);
        map.put("noterima", noterima);
        map.put("nofaktur", nofaktur);
        map.put("remark", remark);
        map.put("tglpo", tglpo);
        map.put("nopo", nopo);
        map.put("tname", tname);
        map.put("kode", kode);
        map.put("kodesup", kodesup);
        map.put("namasup", namasup);
        map.put("tgl", tgl);
        map.put("total", total);
        map.put("grandtotal", grandtotal);
        map.put("sperson", sperson);
        map.put("address1", address1);
        map.put("address2", address2);
        map.put("ppn", ppn);

        return map;
    }
    
    public Map<String, Object> getMapTis() {
        Map<String, Object> map = new HashMap<>();

        map.put("tglterima", tglterima);
        map.put("noterima", noterima);
        map.put("address1", address1);
        map.put("address2", address2);
        map.put("sperson", sperson);
        map.put("tgl", tgl);

        return map;
    }
    
    public Map<String, Object> getMapLkso() {
        Map<String, Object> map = new HashMap<>();

        map.put("noterima", noterima);
        map.put("sname", sname);
        map.put("tglterima", tglterima);
        map.put("sperson", sperson);
        map.put("tgl", tgl);

        return map;
    }

    public String printPo(String[][] data) {
        try {
            JsonTemplate template = new JsonTemplate(getClass().getResourceAsStream("template_po.json"));
            Map<String, Object> map = getMapPo();

            List<Map<String, Object>> tables = new ArrayList<>();
            
            for (int i = 0; i < data.length; i++) {
                Map<String, Object> line = new HashMap<>();
                line.put("no", data[i][0]);
                line.put("code", data[i][1]);
                line.put("name", data[i][2]);
                line.put("qty", data[i][3]);
                line.put("unit", data[i][4]);
                line.put("price", data[i][5]);
                line.put("subtotal", data[i][6]);
                tables.add(line);
            }
            map.put("table_source", tables);
            
// Error
//            SimpleEscp simpleEscp = new SimpleEscp();
//            simpleEscp.useDefaultPrinter();
//            simpleEscp.print(template, map);
            
            PrintService[] services = PrintServiceLookup.lookupPrintServices(null, null);
            if (services.length == 0)
                return "Teu aya printerna";
            
            DocPrintJob job = services[0].createPrintJob();
            PrintRequestAttributeSet aset = new HashPrintRequestAttributeSet();
            
            FillJob fillJob = new FillJob(template.parse(), DataSources.from(map));
            Charset charset = Charset.isSupported("ISO-8859-1") ? Charset.forName("ISO-8859-1")
                    : StandardCharsets.US_ASCII;
            InputStream in = new ByteArrayInputStream(fillJob.fill().getBytes(charset));
            Doc doc = new SimpleDoc(in, DocFlavor.INPUT_STREAM.AUTOSENSE, null);
            job.print(doc, aset);

            return "OK";
        } catch (Exception ex) {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            ex.printStackTrace(pw);
            return sw.toString(); // stack trace as a string
        }
    }

    public String printGr(String[][] data) {
        try {
            JsonTemplate template = new JsonTemplate(getClass().getResourceAsStream("template_gr.json"));
            Map<String, Object> map = getMapGr();

            List<Map<String, Object>> tables = new ArrayList<>();
            if (data != null) {
                for (int i = 0; i < data.length; i++) {
                    Map<String, Object> line = new HashMap<>();
                    line.put("artikel", data[i][0]);
                    line.put("deskripsi", data[i][1]);
                    line.put("satuan", String.format("%9s", data[i][2]));
                    line.put("qty", String.format("%5s", data[i][3]));
                    line.put("uom", data[i][4]);
                    line.put("dpp", String.format("%9s", data[i][5]));
                    line.put("ppn", String.format("%9s", data[i][6]));
                    line.put("total", String.format("%10s", data[i][7]));
                    tables.add(line);
                }
            }
            map.put("table_source", tables);

// Error
//            SimpleEscp simpleEscp = new SimpleEscp();
//            simpleEscp.useDefaultPrinter();
//            simpleEscp.print(template, map);

            PrintService[] services = PrintServiceLookup.lookupPrintServices(null, null);
            if (services.length == 0)
                return "Teu aya printerna";
            
            DocPrintJob job = services[0].createPrintJob();
            PrintRequestAttributeSet aset = new HashPrintRequestAttributeSet();
            
            FillJob fillJob = new FillJob(template.parse(), DataSources.from(map));
            Charset charset = Charset.isSupported("ISO-8859-1") ? Charset.forName("ISO-8859-1")
                    : StandardCharsets.US_ASCII;
            InputStream in = new ByteArrayInputStream(fillJob.fill().getBytes(charset));
            Doc doc = new SimpleDoc(in, DocFlavor.INPUT_STREAM.AUTOSENSE, null);
            job.print(doc, aset);

            return "OK";
        } catch (Exception ex) {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            ex.printStackTrace(pw);
            return sw.toString(); // stack trace as a string
        }
    }
    
    public String printTis(String[][] data) {
        try {
            JsonTemplate template = new JsonTemplate(getClass().getResourceAsStream("template_tis.json"));
            Map<String, Object> map = getMapTis();

            List<Map<String, Object>> tables = new ArrayList<>();
            if (data != null) {
                for (int i = 0; i < data.length; i++) {
                    Map<String, Object> line = new HashMap<>();
                    line.put("code", data[i][0]);
                    line.put("merk", data[i][1]);
                    line.put("category", data[i][2]);
                    line.put("article", data[i][3]);
                    line.put("qty", String.format("%9s", data[i][4]));
                    tables.add(line);
                }
            }
            map.put("table_source", tables);

// Error
//            SimpleEscp simpleEscp = new SimpleEscp();
//            simpleEscp.useDefaultPrinter();
//            simpleEscp.print(template, map);

            PrintService[] services = PrintServiceLookup.lookupPrintServices(null, null);
            if (services.length == 0)
                return "Teu aya printerna";
            
            DocPrintJob job = services[0].createPrintJob();
            PrintRequestAttributeSet aset = new HashPrintRequestAttributeSet();
            
            FillJob fillJob = new FillJob(template.parse(), DataSources.from(map));
            Charset charset = Charset.isSupported("ISO-8859-1") ? Charset.forName("ISO-8859-1")
                    : StandardCharsets.US_ASCII;
            InputStream in = new ByteArrayInputStream(fillJob.fill().getBytes(charset));
            Doc doc = new SimpleDoc(in, DocFlavor.INPUT_STREAM.AUTOSENSE, null);
            job.print(doc, aset);

            return "OK";
        } catch (Exception ex) {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            ex.printStackTrace(pw);
            return sw.toString(); // stack trace as a string
        }
    }
    
    public String printLkso(String[][] data) {
        try {
            JsonTemplate template = new JsonTemplate(getClass().getResourceAsStream("template_lkso.json"));
            Map<String, Object> map = getMapLkso();

            List<Map<String, Object>> tables = new ArrayList<>();
            if (data != null) {
                for (int i = 0; i < data.length; i++) {
                    Map<String, Object> line = new HashMap<>();
                    line.put("no", data[i][0]);
                    line.put("nama", data[i][1]);
                    line.put("qty", String.format("%19s", data[i][2]));
                    line.put("barcode", data[i][3]);
                    tables.add(line);
                }
            }
            map.put("table_source", tables);

// Error
//            SimpleEscp simpleEscp = new SimpleEscp();
//            simpleEscp.useDefaultPrinter();
//            simpleEscp.print(template, map);

            PrintService[] services = PrintServiceLookup.lookupPrintServices(null, null);
            if (services.length == 0)
                return "Teu aya printerna";
            
            DocPrintJob job = services[0].createPrintJob();
            PrintRequestAttributeSet aset = new HashPrintRequestAttributeSet();
            
            FillJob fillJob = new FillJob(template.parse(), DataSources.from(map));
            Charset charset = Charset.isSupported("ISO-8859-1") ? Charset.forName("ISO-8859-1")
                    : StandardCharsets.US_ASCII;
            InputStream in = new ByteArrayInputStream(fillJob.fill().getBytes(charset));
            Doc doc = new SimpleDoc(in, DocFlavor.INPUT_STREAM.AUTOSENSE, null);
            job.print(doc, aset);

            return "OK";
        } catch (Exception ex) {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            ex.printStackTrace(pw);
            return sw.toString(); // stack trace as a string
        }
    }
}
